const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 8787;


const ROOT = __dirname;
const CONFIG_PATH = path.join(ROOT, "config.json");

app.use(express.json({ limit: "2mb" }));
app.use(express.static(ROOT));

// Read config.json
app.get("/api/config", (req, res) => {
  try {
    if (!fs.existsSync(CONFIG_PATH)) {
      fs.writeFileSync(CONFIG_PATH, "{}", "utf8");
    }
    const raw = fs.readFileSync(CONFIG_PATH, "utf8");
    res.type("application/json").send(raw || "{}");
  } catch (err) {
    res.status(500).json({ ok: false, error: String(err) });
  }
});

// Write config.json
app.post("/api/config", (req, res) => {
  try {
    const data = req.body || {};
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(data, null, 2), "utf8");
    res.json({ ok: true, path: CONFIG_PATH });
  } catch (err) {
    res.status(500).json({ ok: false, error: String(err) });
  }
});

app.listen(PORT, "127.0.0.1", () => {
  console.log(`Server running at http://127.0.0.1:${PORT}`);
});