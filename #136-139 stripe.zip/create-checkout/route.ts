// src/app/api/stripe/create-checkout-session/route.ts
import { auth, clerkClient } from "@clerk/nextjs/server";
import { NextResponse } from "next/server";
import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2025-01-27.acacia",
});

export async function POST(req: Request) {
  // 1. Authenticate the Clerk user
  const { userId } = await auth();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  // 2. Get the Clerk user to check for existing Stripe customer
  const client = await clerkClient();
  const user = await client.users.getUser(userId);
  const metadata = user.unsafeMetadata as {
    role?: string;
    stripeCustomerId?: string;
  };

  // 3. Create or reuse a Stripe customer linked to this Clerk user
  let stripeCustomerId = metadata.stripeCustomerId;

  if (!stripeCustomerId) {
    const customer = await stripe.customers.create({
      email: user.emailAddresses[0]?.emailAddress,
      name: `${user.firstName ?? ""} ${user.lastName ?? ""}`.trim() || undefined,
      metadata: {
        clerkUserId: userId,
      },
    });

    stripeCustomerId = customer.id;

    // Save the Stripe customer ID back to Clerk user metadata
    await client.users.updateUser(userId, {
      unsafeMetadata: {
        ...metadata,
        stripeCustomerId,
      },
    });
  }

  // 4. Parse optional priceId from request body (falls back to env default)
  let priceId: string | undefined;
  try {
    const body = await req.json();
    priceId = body?.priceId;
  } catch {
    // No body or invalid JSON — use default
  }

  const resolvedPriceId = priceId ?? process.env.STRIPE_DEFAULT_PRICE_ID;

  if (!resolvedPriceId) {
    return NextResponse.json(
      { error: "No priceId provided and STRIPE_DEFAULT_PRICE_ID is not set." },
      { status: 400 }
    );
  }

  // 5. Create the Stripe Checkout Session in subscription mode
  const session = await stripe.checkout.sessions.create({
    mode: "subscription",
    customer: stripeCustomerId,
    line_items: [
      {
        price: resolvedPriceId,
        quantity: 1,
      },
    ],
    // Clerk userId in metadata so webhooks can look it up
    subscription_data: {
      metadata: {
        clerkUserId: userId,
      },
    },
    success_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard?checkout=success`,
    cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard?checkout=cancelled`,
  });

  return NextResponse.json({ url: session.url });
}